function Contact(){
    return (
        <>
        <h1>Contact Page</h1>
        <strong>Team Members:</strong> 
        <ol>
            <li>Harshitha R S</li>
            <li>Shweta Hiremath</li>
            <li>Priyanka V Patil</li>
        </ol>

        </>
    );
}
export default Contact;