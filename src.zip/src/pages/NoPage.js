function NoPage(){
    return (
        <>
        <h1>Sorry your requested page does not exists !</h1>
        </>
    );
}
export default NoPage;